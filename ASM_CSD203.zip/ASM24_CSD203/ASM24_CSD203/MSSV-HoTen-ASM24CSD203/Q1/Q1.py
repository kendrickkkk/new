class Stack:
    def __init__(self):
        self.data = []

    def push(self, item):
        self.data.append(item)

    def pop(self):
        if not self.data:
            print("STACK is empty")
            return None
        return self.data.pop()

    def print(self):
        print(*self.data)

    def isEmpty(self):
        return not bool(self.data)

    def size(self):
        return len(self.data)

    def top(self):
        if not self.data:
            print("STACK is empty")
            return None
        return self.data[-1]

    # Q1: Calculate avg in stack
    def f1(self):
        # =========================================
        # === BEGIN YOUR CODE HERE
        return sum(self.data)/len(self.data)

       



        # === END YOUR CODE

        # Q2: Find the max in the stack
    def f2(self):
    # =========================================
        # === BEGIN YOUR CODE HERE
        return max(self.data)
       



        # === END YOUR CODE

    # Q3: Calculate the sum of the elements in the stack.
    def f3(self):
       # =========================================
        # === BEGIN YOUR CODE HERE
        return sum(self.data)
       



        # === END YOUR CODE

        
    # Q4: Find even numbers in the stack and print them.
    def f4(self):
       # =========================================
        # === BEGIN YOUR CODE HERE
        a=[]
        for i in self.data:
            if i % 2 ==0:
                a.append(i)
        return a


        # === END YOUR CODE

    # Q5: Find odd numbers in the stack and print them.
    def f5(self):
       # =========================================
        # === BEGIN YOUR CODE HERE
        a=[]
        for i in self.data:
            if i % 2 !=0:
                a.append(i)
        return a

       



        # === END YOUR CODE

def main():
    print("Do you want to run Q1?")
    print("1. Run f1()")
    print("2. Run f2()")
    print("3. Run f3()")
    print("4. Run f4()")
    print("5. Run f5()")

    n = int(input("Enter a number : "))

    s1 = Stack()
    s1.push(1)
    s1.push(2)
    s1.push(3)
    s1.push(4)
    s1.push(5)

    if n == 1:
        result = s1.f1()
        print("OUTPUT:")
        print(result)

    if n == 2:
        result = s1.f2()
        print("OUTPUT:")
        print(result)

    if n == 3:
        result = s1.f3()
        print("OUTPUT:")
        print(result)

    if n == 4:
        result = s1.f4()
        print("OUTPUT:")
        print(*result)

    if n == 5:
        result = s1.f5()
        print("OUTPUT:")
        print(*result)


# end main
# --------------------------------
if __name__ == "__main__":
    main()
# ============================================================