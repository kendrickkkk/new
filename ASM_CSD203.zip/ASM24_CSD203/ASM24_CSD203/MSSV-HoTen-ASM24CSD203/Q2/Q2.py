class BinarySearchTree:
    def __init__(self, data=None):
        self.data = data
        self.left = None
        self.right = None

    def addNode(self, item):
        if self.data == item:
            return
        elif self.data < item:
            if not self.right:
                self.right = BinarySearchTree(item)
            else:
                self.right.addNode(item)
        elif self.data > item:
            if not self.left:
                self.left = BinarySearchTree(item)
            else:
                self.left.addNode(item)

    def search(self, item):
        if self.data == item:
            return True
        elif self.data < item:
            return self.right.search(item) if self.right else False
        return self.left.search(item) if self.left else False

    def min(self):
        if self.left:
            return self.left.min()
        return self.data

    def max(self):
        if self.right:
            return self.right.max()
        return self.data

    def sum(self):
        total_sum = self.data
        if self.left:
            total_sum += self.left.sum()
        if self.right:
            total_sum += self.right.sum()
        return total_sum

    def delete(self, item):
        if self.data > item:
            if self.left:
                self.left = self.left.delete(item)
        elif self.data < item:
            if self.right:
                self.right = self.right.delete(item)
        else:
            if self.left is None and self.right is None:
                return None
            elif self.left is None:
                return self.right
            elif self.right is None:
                return self.left
            else:
                min_val = self.right.min()
                self.data = min_val
                self.right = self.right.delete(min_val)
        return self

    def inOrderTraversal(self):
        temp = []
        if self.left:
            temp += self.left.inOrderTraversal()
        temp.append(self.data)
        if self.right:
            temp += self.right.inOrderTraversal()
        return temp

    def preOrderTraversal(self):
        temp = []
        temp.append(self.data)
        if self.left:
            temp += self.left.preOrderTraversal()
        if self.right:
            temp += self.right.preOrderTraversal()
        return temp

    def postOrderTraversal(self):
        temp = []
        if self.left:
            temp += self.left.postOrderTraversal()
        if self.right:
            temp += self.right.postOrderTraversal()
        temp.append(self.data)
        return temp

    def print(self):
        if self.left:
            self.left.print()
        print(self.data, end=" ")
        if self.right:
            self.right.print()

    # Q1: Find the sum of all values in the left subtree.
    def f1(self):
        # =========================================
        # === BEGIN YOUR CODE HERE
        a=0
        if self.left:
            a+=self.left.sum()
        return a
       



        # === END YOUR CODE

    # Q2: Find the minimum value in the left sub tree.
    def f2(self):
       # =========================================
        # === BEGIN YOUR CODE HERE
        return self.min()
       



        # === END YOUR CODE

    # Q3: Check if the tree has 17 in it.
    def f3(self):
       # =========================================
        # === BEGIN YOUR CODE HERE
        return self.search(17)
       



        # === END YOUR CODE

    # Q4: Find the maximum value in the right subtree.
    def f4(self):
        # =========================================
        # === BEGIN YOUR CODE HERE
        return self.max()
       



        # === END YOUR CODE

    # Q5: Find the sum of all values in the right subtree.
    def f5(self):
        # =========================================
        # === BEGIN YOUR CODE HERE
        a=0
        if self.right:
            a+=self.right.sum()
        return a
       



        # === END YOUR CODE

def main():
    s1 = BinarySearchTree(10)
    s1.addNode(5)
    s1.addNode(15)
    s1.addNode(3)
    s1.addNode(4)
    s1.addNode(1)
    s1.addNode(6)
    s1.addNode(12)
    s1.addNode(17)

    print("Do you want to run Q1?")
    print("1. Run f1()")
    print("2. Run f2()")
    print("3. Run f3()")
    print("4. Run f4()")
    print("5. Run f5()")

    n = int(input("Enter a number : "))

    if n == 1:
        result = s1.f1()
        print("OUTPUT:")
        print(result)

    if n == 2:
        result = s1.f2()
        print("OUTPUT:")
        print(result)

    if n == 3:
        result = s1.f3()
        print("OUTPUT:")
        print(result)

    if n == 4:
        result = s1.f4()
        print("OUTPUT:")
        print(result)

    if n == 5:
        result = s1.f5()
        print("OUTPUT:")
        print(result)


# end main
# --------------------------------
if __name__ == "__main__":
    main()
# ============================================================