class ArrayDEQue:
    def __init__(self):
        self._data = []

    def __len__(self):
        return len(self._data)

    def is_empty(self):
        return len(self._data) == 0

    def add_front(self, element):
        self._data.insert(0, element)

    def add_rear(self, element):
        self._data.append(element)

    def remove_front(self):
        if self.is_empty():
            print('DEQue is Empty')
            return
        return self._data.pop(0)

    def remove_rear(self):
        if self.is_empty():
            print('DEQue is Empty')
            return
        return self._data.pop()

    def peek(self):
        if self.is_empty():
            print('DEQue is Empty')
            return
        return self._data[0]

    def rear(self):
        if self.is_empty():
            print('DEQue is Empty')
            return
        return self._data[-1]

    @property
    def data(self):
        return self._data

    #Q1: Find if x = 3 in the arry
    def f1(self):
        # =========================================
        # === BEGIN YOUR CODE HERE
        for i in self._data:
            if i ==3:
                return True
        return False
       



        # === END YOUR CODE

    #Q2: Find sum in the arry
    def f2(self):
        # =========================================
        # === BEGIN YOUR CODE HERE
        return sum(self._data)
       



        # === END YOUR CODE
    #Q3: Find even num in the array
    def f3(self):
        # =========================================
        # ==
        # = BEGIN YOUR CODE HERE
        a=[]
        for i in self._data:
            if i %2==0:
                a.append(i)
        return a



        # === END YOUR CODE
    #Q4: Find odd num in the array
    def f4(self):
        # =========================================
        # === BEGIN YOUR CODE HERE
        
        a=[]
        for i in self._data:
            if i %2!=0:
                a.append(i)
        return a



        # === END YOUR CODE
    #Q5: Find the max num in the array
    def f5(self):
        # =========================================
        # === BEGIN YOUR CODE HERE
        return max(self._data)
       



        # === END YOUR CODE

def main():
    s1 = ArrayDEQue()
    s1.add_front(5)
    s1.add_front(3)
    s1.add_front(7)
    s1.add_rear(8)
    s1.add_rear(12)
    s1.add_rear(24)
    print("Do you want to run Q1?")
    print("1. Run f1()")
    print("2. Run f2()")
    print("3. Run f3()")
    print("4. Run f4()")
    print("5. Run f5()")

    n = int(input("Enter a number : "))

    if n == 1:
        result = s1.f1()
        print("OUTPUT:")
        print(result)

    if n == 2:
        result = s1.f2()
        print("OUTPUT:")
        print(result)

    if n == 3:
        result = s1.f3()
        print("OUTPUT:")
        print(*result)

    if n == 4:
        result = s1.f4()
        print("OUTPUT:")
        print(*result)

    if n == 5:
        result = s1.f5()
        print("OUTPUT:")
        print(result)


# end main
# --------------------------------
if __name__ == "__main__":
    main()
# ============================================================