class ArrayQueue:
    def __init__(self):
        self._data = []

    def __len__(self):
        return len(self._data)

    def is_empty(self):
        return len(self._data) == 0

    def enqueue(self, element):
        self._data.append(element)

    def dequeue(self):
        if self.is_empty():
            print('Queue is Empty')
            return
        return self._data.pop(0)

    def peek(self):
        if self.is_empty():
            print('Queue is Empty')
            return
        return self._data[0]
    #Q1 Find the even num in the array
    def f1(self):
        # =========================================
        # === BEGIN YOUR CODE HERE
        a=[]
        for i in self._data:
            if i %2==0:
                a.append(i)
        return a
       



        # === END YOUR CODE

    #Q2 Find the odd num in the array
    def f2(self):
        # =========================================
        # === BEGIN YOUR CODE HERE
        a=[]
        for i in self._data:
            if i %2!=0:
                a.append(i)
        return a
       



        # === END YOUR CODE

    #Q3 Check if the odd sum and even sum is balanced
    def f3(self):
        # =========================================
        # === BEGIN YOUR CODE HERE
        a=self.f1()
        b=self.f2()
        if len(a)==len(b):
            return True
        return False



        # === END YOUR CODE

    #Q4 Find the max num
    def f4(self):
        # =========================================
        # === BEGIN YOUR CODE HERE
        return max(self._data)
       



        # === END YOUR CODE

    #Q5 Find the min num
    def f5(self):
        # =========================================
        # === BEGIN YOUR CODE HERE
        return min(self._data)
       



        # === END YOUR CODE


def main():
    s1 = ArrayQueue()
    s1.enqueue(5)
    s1.enqueue(8)
    s1.enqueue(1)
    s1.enqueue(7)
    s1.enqueue(12)
    print("Do you want to run Q1?")
    print("1. Run f1()")
    print("2. Run f2()")
    print("3. Run f3()")
    print("4. Run f4()")
    print("5. Run f5()")

    n = int(input("Enter a number : "))

    if n == 1:
        result = s1.f1()
        print("OUTPUT:")
        print(*result)

    if n == 2:
        result = s1.f2()
        print("OUTPUT:")
        print(*result)

    if n == 3:
        result = s1.f3()
        print("OUTPUT:")
        print(result)

    if n == 4:
        result = s1.f4()
        print("OUTPUT:")
        print(result)

    if n == 5:
        result = s1.f5()
        print("OUTPUT:")
        print(result)


# end main
# --------------------------------
if __name__ == "__main__":
    main()
# ============================================================