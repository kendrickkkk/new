class Emp:
    def __init__(self, name, ID, Job, Salary):
        self.name = name
        self.ID = ID
        self.Job = Job
        self.Salary = Salary

class Node:
    def __init__(self, value):
        self.data = value
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None
        self.tail = None

    def addLast(self, name, ID, Job, Salary):
        n = Emp(name, ID, Job, Salary)
        new_node = Node(n)
        if self.head is None:
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node

    def loadData(self):
        self.addLast("Ane", "1701", 'Doctor' , 5000)
        self.addLast("Bane", "1702", "Engineer" , 4000)
        self.addLast("Cane", "1706", "Teacher" , 2000)
        self.addLast("Deck", "1801", "Nurse" , 2500)
        self.addLast("Emily", "1802", "Nurse", 2500)

    #Find all the name of employee whose job is "nurse"
    def f1(self):
        # =========================================
        # === BEGIN YOUR CODE HERE
        a=[]
        tmp=self.head
        while tmp:
            if tmp.data.Job == 'Nurse':
                a.append(tmp.data.name)
            tmp=tmp.next
        return a


        # === END YOUR CODE

    #Find the ID of the name "Ane":
    def f2(self):
         # =========================================
        # === BEGIN YOUR CODE HERE
        a=[]
        tmp=self.head
        while tmp:
            if tmp.data.name == 'Ane':
                a.append(tmp.data.ID)
            tmp=tmp.next
        return a
       



        # === END YOUR CODE


    #Find the even num from ID and return the name of even ID:
    def f3(self):
         # =========================================
        # === BEGIN YOUR CODE HERE
        a=[]
        tmp=self.head
        while tmp:
            if int(tmp.data.ID) % 2==0 :
                a.append(tmp.data.name)
            tmp=tmp.next
        return a
       



        # === END YOUR CODE


    #Find the sum of even num from ID:
    def f4(self):
        # =========================================
        # === BEGIN YOUR CODE HERE
        a=[]
        tmp=self.head
        while tmp:
            if int(tmp.data.ID) % 2==0 :
                a.append(int(tmp.data.ID))
            tmp=tmp.next
        return sum(a)
       



        # === END YOUR CODE

    #Find the avg of ID:
    def f5(self):
        # =========================================
        # === BEGIN YOUR CODE HERE
        # === BEGIN YOUR CODE HERE
        a=[]
        tmp=self.head
        while tmp:
            a.append(int(tmp.data.ID))
            tmp=tmp.next
        return sum(a)/len(a)




        # === END YOUR CODE





# ========================DO NOT EDIT GIVEN STATEMENTS IN THE MAIN FUNCTION.============================
# ===IF YOU CHANGE, THE GRADING SOFTWARE CAN NOT FIND THE OUTPUT RESULT TO SCORE, THUS THE MARK IS 0.===
def main():
    lst = LinkedList()
    lst.loadData()
    print("Do you want to run Q1?")
    print("1. Run f1()")
    print("2. Run f2()")
    print("3. Run f3()")
    print("4. Run f4()")
    print("5. Run f5()")

    n = int(input("Enter a number : "))

    if n == 1:
        result = lst.f1()
        print("OUTPUT:")
        print(*result)

    if n ==2:
        result = lst.f2()
        print("OUTPUT:")
        print(result)

    if n == 3:
        result = lst.f3()
        print("OUTPUT:")
        print(*result)

    if n == 4:
        result = lst.f4()
        print("OUTPUT:")
        print(result)

    if n == 5:
        result = lst.f5()
        print("OUTPUT:")
        print(result)


# end main
# --------------------------------
if __name__ == "__main__":
    main()
# ============================================================